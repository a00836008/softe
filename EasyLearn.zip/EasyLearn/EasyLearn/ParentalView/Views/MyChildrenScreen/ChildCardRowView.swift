import SwiftUI

struct ChildCardRowView: View {
    let child: Child
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                VStack(alignment: .leading, spacing: 8) {
                    Text(child.name)
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.black)

                    Text("Age: \(child.age)")
                        .fontWeight(.semibold)
                        .foregroundColor(.black)

                    Text("Grade: \(child.grade)")
                        .fontWeight(.semibold)
                        .foregroundColor(.black)

                    Text("Gender: \(child.gender)")
                        .fontWeight(.semibold)
                        .foregroundColor(.black)
                }
                .layoutPriority(1)

                Spacer()

                Image(systemName: "person.circle")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 100, height: 100)
                    .clipped()
                    .cornerRadius(10)
            }

            NavigationLink(destination: ChildCardView(child: child)) {
                Text("View Details")
                    .font(.headline)
                    .fontWeight(.semibold)
                    .padding(.vertical, 8)
                    .frame(maxWidth: .infinity)
                    .background(Color(red: 0.0/255, green: 59.0/255, blue: 92.0/255))
                    .cornerRadius(8)
                    .foregroundColor(.white)
            }
            .padding()
        }
        .padding(12)
        .background(Color(red: 209.0/255, green: 224.0/255, blue: 215.0/255))
        .cornerRadius(15)
        .shadow(radius: 5)
    }
}

struct ChildCardRowView_Previews: PreviewProvider {
    static var previews: some View {
        ChildCardRowView(child: Child(
            id: UUID(),
            name: "Daniela",
            age: 6,
            gender: "Female",
            grade: 4,
            scores: [
                Assignment(name: "Math Assignment 1", score: 8, subject: "Math"),
                Assignment(name: "Math Assignment 2", score: 9, subject: "Math")
            ],
            goals: ["Math": 90, "Spanish": 80, "English": 85]
        ))
        .previewLayout(.sizeThatFits)
        .padding()
    }
}
